package backend;

public class MipsIns extends Mips{

}
