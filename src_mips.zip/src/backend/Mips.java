package backend;

import midend.llvm.FuncDecl;
import midend.llvm.ValueFuncDef;
import midend.llvm.ValueGlobalDef;
import utils.Writer;

public class Mips {


    public int writeMips(Writer writer) {

        return 0;
    }


}
