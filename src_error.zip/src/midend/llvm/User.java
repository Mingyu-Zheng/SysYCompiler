package midend.llvm;

public class User extends Value{

}
